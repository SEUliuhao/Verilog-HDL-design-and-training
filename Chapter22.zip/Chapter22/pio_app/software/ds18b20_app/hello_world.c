/******************************************************************************
*******************************************************************************
************������VHDL��FPGA��NIOS IIʵ������������Դ����**********************
*****************��ӭ�����뽻�� Email:edafarm@163.com**************************
*******************************************************************************
******************************************************************************/
#include <stdio.h>
#include "system.h";
#include "alt_types.h"
#include "altera_avalon_pio_regs.h"

//дָ��
void lcd_wrcom(alt_u8 data)
{
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_RS_BASE, 0);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_WR_BASE, 0);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 0);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_D_BASE,data);
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 1);
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 0);
}

//д����
void lcd_wrdata(alt_u8 data)
{
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_RS_BASE, 1);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_WR_BASE, 0);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 0);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_D_BASE,data);
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 1);
    usleep(1000);
    IOWR_ALTERA_AVALON_PIO_DATA(LCD_E_BASE, 0);
}

//LCD��ʼ��
void lcd_init()
{
    usleep(15000);
    lcd_wrcom(0x38);
    usleep(5000);
    lcd_wrcom(0x08);
    usleep(5000);
    lcd_wrcom(0x01);
    usleep(5000);
    lcd_wrcom(0x06);
    usleep(5000);
    lcd_wrcom(0x0c);
    usleep(5000);
}
    
void lcd_display(alt_u8 line, alt_u8 *data)
{
    if(line == 1)
        lcd_wrcom(0x80);
    else
        lcd_wrcom(0xc0);
    
    while(*data != '\0')
    {
        lcd_wrdata(*data);
        data++;
        usleep(1000);
    }
}

//ds18b20 ��λ
void ds18b20rst()
{
    IOWR_ALTERA_AVALON_PIO_DIRECTION(DS18B20_BASE,1);
    IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 1);
    usleep(4);
    IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 0);
    usleep(100);
    IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 1);
    usleep(40);
}

//ds18b20������
alt_u8 ds18b20rd()
{   
    alt_u8 i = 0;
    alt_u8 data = 0;
    for(i = 0; i < 8; i++)
    {
        IOWR_ALTERA_AVALON_PIO_DIRECTION(DS18B20_BASE,1);
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 0);
        usleep(2);        
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 1);
        usleep(4);
        IOWR_ALTERA_AVALON_PIO_DIRECTION(DS18B20_BASE,0);
        if(IORD_ALTERA_AVALON_PIO_DATA(DS18B20_BASE))
            data = data | 0x80;
        data = data >> 1;
        IOWR_ALTERA_AVALON_PIO_DIRECTION(DS18B20_BASE,1);
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 1);
        usleep(4);
    }
    return data;
}

//д����
void ds18b20wr(alt_u8 data)
{
    alt_u8 i = 0;
    for(i = 0; i < 8; i++)
    {
        IOWR_ALTERA_AVALON_PIO_DIRECTION(DS18B20_BASE,1);
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 0);
        usleep(2);        
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, data & 0x01);
        usleep(60);
        IOWR_ALTERA_AVALON_PIO_DATA(DS18B20_BASE, 1);
        data = data >> 1;
    }
}

//��ȡ�¶�
alt_u8 pn = 0;

alt_u16 read_temp()
{
    alt_u8 i = 0;
    alt_u8 j = 0;
    alt_u16 temp = 0;
    ds18b20rst();
    ds18b20wr(0xcc);
    ds18b20wr(0x44);
    ds18b20rst();
    ds18b20wr(0xcc);
    ds18b20wr(0xbe);
    i = ds18b20rd();
    j = ds18b20rd();
    temp = j;
    temp = temp << 8;
    temp = temp | i;
    
    if(temp < 0x0fff)
        pn = 0;
    else
    {
        temp = ~temp + 1;
        pn = 1;
    }
    
    temp = temp * 0.652;
    
    return temp;  
    
}

//��ʾ
alt_u8 displaydata[4];
void tempdisplay()
{
    alt_u16 temp = 0;
    temp = read_temp();
    displaydata[0] = temp/1000 + 0x30;
    displaydata[1] = (temp%1000)/100 + 0x30;
    displaydata[2] = (temp%100)/10 + 0x30;
    displaydata[3] = temp%10 + 0x30;  
    
    lcd_wrcom(0xc0);
    if(pn)
        lcd_wrdata(0x2d);
    else
        lcd_wrdata(0x20);
    
    lcd_wrcom(0xc1);
    if(displaydata[0] == 0x30)
        lcd_wrdata(0x20);
    else
        lcd_wrdata(displaydata[0]);
    
    lcd_wrcom(0xc2);
    if(displaydata[1] == 0x30)
        lcd_wrdata(0x20);
    else
        lcd_wrdata(displaydata[1]);
    
    lcd_wrcom(0xc3) ;  
    lcd_wrdata(displaydata[2]);
     
    lcd_wrcom(0xc4);  
    lcd_wrdata(0x2e);
    
    lcd_wrcom(0xc5);
    lcd_wrdata(displaydata[3]); 
        
}



        
    


int main()
{
  alt_u8 chr[10] = {'t', 'e', 'm', 'p', 'e', 'r', 'a', 't', 'u', 'r', 'e'};
  printf("Hello from Nios II!\n");
  lcd_init();
  lcd_display(1, chr);
  while(1)
  {
    read_temp();
    tempdisplay();
    usleep(1000000);
  }
  

  return 0;
}
