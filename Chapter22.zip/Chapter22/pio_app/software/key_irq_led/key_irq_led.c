/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */
#include <stdio.h>
#include "system.h"; //ϵͳ����ͷ�ļ�
#include "alt_types.h"
#include "altera_avalon_pio_regs.h" //PIO��ص�ͷ�ļ�


static alt_u8 cnt;

static void key_isr(void * context, alt_u32 id)
{
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_BASE, 0X0);
	cnt = cnt + 1;
	printf("The key irq generates!\n");
}

int main()
{
  printf("Hello from Nios II!\n");
  printf("hope you like this book - ��Verilog HDL �����ʵս��\n");

  IOWR_ALTERA_AVALON_PIO_IRQ_MASK(KEY_BASE, 0x01);
  IOWR_ALTERA_AVALON_PIO_EDGE_CAP(KEY_BASE, 0X00);
  alt_irq_register(KEY_IRQ, 0, key_isr);
  while(1)
  {
	  usleep(100000);
	  IOWR_ALTERA_AVALON_PIO_DATA(LED_BASE, cnt);
  }
  return 0;
}
