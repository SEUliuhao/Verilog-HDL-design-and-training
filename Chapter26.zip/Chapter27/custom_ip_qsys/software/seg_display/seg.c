/*
 * seg.c
 *
 *  Created on: 2012-4-2
 *      Author: LIUFUQI
 */
#include "seg.h"
void seg_show(int data)
{
	int temp = 0;
	int show = 0;
	if(data > 99999999)
	{
		temp = data % 100000000;
	}
	else
	{
		temp = data;
	}
	show = temp % 10 + ((temp % 100)/10) * 16 + ((temp % 1000)/100) * 256 + ((temp % 10000)/1000) * 16 * 16 * 16
			+ ((temp % 100000)/10000) * 16*16*16*16 + ((temp % 1000000)/100000) * 16*16*16*16*16+ ((temp % 10000000)/1000000) * 16*16*16*16*16
			+ + ((temp % 100000000)/10000000) * 16*16*16*16*16*16*16;
	IOWR(SEG_DISPLAY_CTRL_0_BASE, 0, show);
}
