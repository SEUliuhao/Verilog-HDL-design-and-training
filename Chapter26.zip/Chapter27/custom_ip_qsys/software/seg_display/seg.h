/*
 * seg.h
 *
 *  Created on: 2012-4-2
 *      Author: LIUFUQI
 */

#ifndef SEG_H_
#define SEG_H_
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include <io.h>

void seg_show(int data);

#endif /* SEG_H_ */
