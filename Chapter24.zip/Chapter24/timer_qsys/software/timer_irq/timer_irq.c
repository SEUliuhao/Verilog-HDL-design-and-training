/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <string.h>
#include "system.h"
#include "alt_types.h"
#include "altera_avalon_pio_regs.h"
#include "altera_avalon_uart_regs.h"
#include "altera_avalon_timer_regs.h"



  static  alt_u8 txdata = 0;
  static  alt_u8 rxdata = 0;
//���嶨ʱ���жϷ�����
//����ʱ��������0ʱ��������ʱ���ж����󣬵��ô˺���
static void timer_isr(void* context, alt_u32 id)
{
   while(!((IORD_ALTERA_AVALON_UART_STATUS(UART_BASE) & ALTERA_AVALON_UART_STATUS_TRDY_MSK)));
        IOWR_ALTERA_AVALON_UART_TXDATA(UART_BASE, txdata);


   IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_BASE, 0);
}

#include <stdio.h>

int main()
{
  alt_irq_register(TIMER_IRQ, 0, timer_isr);
   //���״̬�Ĵ�����ֵ
  IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_BASE,0);
  //��ʼ�����ƼĴ�����ֵ
  //ʹ���жϡ�������������ʼ����
  IOWR_ALTERA_AVALON_TIMER_CONTROL(TIMER_BASE,0x07);
  while(1)
  {
	   while(!((IORD_ALTERA_AVALON_UART_STATUS(UART_BASE) & ALTERA_AVALON_UART_STATUS_RRDY_MSK)));
			rxdata = IORD_ALTERA_AVALON_UART_RXDATA(UART_BASE);
			IOWR_ALTERA_AVALON_PIO_DATA(LED_BASE, rxdata);
	   usleep(100);
  }
  return 0;
}

