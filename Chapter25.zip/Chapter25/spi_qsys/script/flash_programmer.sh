#!/bin/sh
#
# This file was automatically generated.
#
# It can be overwritten by nios2-flash-programmer-generate or nios2-flash-programmer-gui.
#

#
# Converting SOF File: H:\fourbook\FB\code\Chapter25\spi_qsys\spi_qsys.sof to: "..\flash/spi_qsys_epcs.flash"
#
$SOPC_KIT_NIOS2/bin/sof2flash --input="H:/fourbook/FB/code/Chapter25/spi_qsys/spi_qsys.sof" --output="../flash/spi_qsys_epcs.flash" --epcs 

#
# Programming File: "..\flash/spi_qsys_epcs.flash" To Device: epcs
#
$SOPC_KIT_NIOS2/bin/nios2-flash-programmer "../flash/spi_qsys_epcs.flash" --base=0x0 --epcs --sidp=0x3828 --id=0x0 --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' --program 

#
# Converting ELF File: H:\fourbook\FB\code\Chapter25\spi_qsys\software\spi_wr\spi_wr.elf to: "..\flash/spi_wr_epcs.flash"
#
$SOPC_KIT_NIOS2/bin/elf2flash --input="H:/fourbook/FB/code/Chapter25/spi_qsys/software/spi_wr/spi_wr.elf" --output="../flash/spi_wr_epcs.flash" --epcs --after="../flash/spi_qsys_epcs.flash" 

#
# Programming File: "..\flash/spi_wr_epcs.flash" To Device: epcs
#
$SOPC_KIT_NIOS2/bin/nios2-flash-programmer "../flash/spi_wr_epcs.flash" --base=0x0 --epcs --sidp=0x3828 --id=0x0 --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' --program 

