sof="spi_qsys.sof" 
elf="spi_wr.elf"

echo "sof>flash ..."; sof2flash --epcs --input=$sof --output=hw.flash --quiet
echo "elf>flash ..."; elf2flash --epcs --after=hw.flash --input=$elf --output=sw.flash
echo "cat flash ..."; cp hw.flash hw_sw.flash; cat sw.flash >> hw_sw.flash
echo "flash>hex ..."; nios2-elf-objcopy --input-target srec --output-target ihex hw_sw.flash hw_sw.hex
echo "del flash ..."; rm -f *.flash
