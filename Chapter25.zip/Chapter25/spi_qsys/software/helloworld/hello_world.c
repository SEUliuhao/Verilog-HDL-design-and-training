/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "altera_avalon_spi_regs.h"



int main()
{

  alt_u8 spi_data = 0;

  alt_u32 spi_status = 0;



  while(1)
  {
    //����SPI���ݣ���״̬�Ĵ�����TRDYλΪ1ʱ����ʾ���Է���SPI���ݡ�
    do{
		 spi_status = IORD_ALTERA_AVALON_SPI_STATUS(SPI_BASE);
	 }while((spi_status & ALTERA_AVALON_SPI_STATUS_TRDY_MSK) != 0x40);
	 IOWR_ALTERA_AVALON_SPI_TXDATA(SPI_BASE, spi_data);
	 
    //��ȡSPI���ݣ���״̬�Ĵ�����RRDYλΪ1ʱ����ʾ���յ������ݣ����Զ�ȡ��
    do{
		 spi_status = IORD_ALTERA_AVALON_SPI_STATUS(SPI_BASE);
	 	 }while((spi_status & ALTERA_AVALON_SPI_STATUS_RRDY_MSK) != 0x80);

	 spi_data = IORD_ALTERA_AVALON_SPI_RXDATA(SPI_BASE);

	 usleep(1000000);
  }

  return 0;
}

